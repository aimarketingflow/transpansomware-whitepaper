#!/bin/bash

# 🎆💣 DIGITAL GLITTER BOMB SETUP SCRIPT 💣🎆
# This script sets up your legal anti-theft honeypot system!

echo "🎆💣 Setting up Digital Glitter Bomb 💣🎆"
echo "The ultimate legal trap for software thieves!"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    echo "Visit: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js found: $(node --version)"
echo "✅ npm found: $(npm --version)"
echo ""

# Install root dependencies
echo "📦 Installing root dependencies..."
npm install

# Setup client
echo "🎨 Setting up client-side glitter bomb..."
cd client
npm install
echo "✅ Client dependencies installed"
cd ..

# Setup server
echo "🖥️ Setting up server-side tracking..."
cd server
npm install
echo "✅ Server dependencies installed"
cd ..

# Create environment file
echo "⚙️ Creating environment configuration..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ Environment file created (.env)"
    echo "📝 Please edit .env with your configuration"
else
    echo "⚠️ Environment file already exists"
fi

# Build TypeScript files
echo "🔨 Building TypeScript files..."
cd client && npm run build
cd ../server && npm run build
cd ..

echo ""
echo "🎉 Digital Glitter Bomb setup complete!"
echo ""
echo "🚀 Next steps:"
echo "1. Edit .env file with your configuration"
echo "2. Start the server: npm run server"
echo "3. Integrate the client library into your software"
echo "4. Deploy your honeypot and catch some thieves! 🎯"
echo ""
echo "📚 See examples/ folder for integration examples"
echo "📊 Open monitoring/dashboard.html to view the admin panel"
echo ""
echo "Happy thief catching! 🕵️‍♂️✨"
