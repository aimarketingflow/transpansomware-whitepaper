/**
 * Example Integration - How to integrate the Anti-Theft Protection System
 * This shows how to legally and transparently protect your software
 */

import { AntiTheftProtection } from '../client/src/AntiTheftProtection.js';

// Example 1: Basic Integration with User Consent
async function basicIntegration() {
  console.log('🛡️ Initializing Anti-Theft Protection...');
  
  const protection = new AntiTheftProtection({
    serverUrl: 'https://your-protection-server.com',
    licenseKey: 'ABCD-1234-EFGH-5678', // Your actual license key
    productId: 'my-awesome-software',
    enableTracking: true,
    userConsent: false // Will show consent dialog
  });

  // Initialize protection system
  const initialized = await protection.initialize();
  
  if (initialized) {
    console.log('✅ Protection system active');
    
    // Your application code continues here
    startApplication();
  } else {
    console.log('❌ Protection system failed - blocking application');
    showLicenseError();
  }
}

// Example 2: Advanced Integration with Custom Consent Flow
async function advancedIntegration() {
  // Show your own custom consent dialog first
  const userConsent = await showCustomConsentDialog();
  
  const protection = new AntiTheftProtection({
    serverUrl: process.env.PROTECTION_SERVER_URL,
    licenseKey: getLicenseFromSecureStorage(),
    productId: 'my-software-v2',
    enableTracking: userConsent,
    userConsent: userConsent
  });

  const initialized = await protection.initialize();
  
  if (initialized) {
    // Log successful initialization (for your own analytics)
    console.log('Protection initialized:', protection.getSessionInfo());
    
    // Continue with your application
    initializeMainApplication();
    
    // Optional: Periodically check protection status
    setInterval(() => {
      if (!protection.isProtectionActive()) {
        console.warn('⚠️ Protection system inactive');
        // Handle protection failure
      }
    }, 60000); // Check every minute
    
  } else {
    handleProtectionFailure();
  }
}

// Example 3: Integration with Error Handling
class ProtectedApplication {
  constructor() {
    this.protection = null;
    this.isProtected = false;
  }

  async initialize() {
    try {
      // Initialize protection first
      await this.initializeProtection();
      
      if (this.isProtected) {
        // Initialize your actual application
        await this.initializeApp();
        console.log('🚀 Application started with protection');
      } else {
        this.showProtectionError();
      }
    } catch (error) {
      console.error('Initialization failed:', error);
      this.handleInitializationError(error);
    }
  }

  async initializeProtection() {
    this.protection = new AntiTheftProtection({
      serverUrl: 'https://protection.mycompany.com',
      licenseKey: this.getLicenseKey(),
      productId: 'protected-app-v1',
      enableTracking: true,
      userConsent: await this.getUserConsent()
    });

    this.isProtected = await this.protection.initialize();
    
    if (this.isProtected) {
      console.log('✅ Software protection active');
    } else {
      console.log('❌ Software protection failed');
    }
  }

  async getUserConsent() {
    // Show a clear, informative consent dialog
    return new Promise((resolve) => {
      const modal = document.createElement('div');
      modal.innerHTML = `
        <div class="consent-modal">
          <h3>Software Protection Notice</h3>
          <p>This software includes anti-theft protection to prevent piracy and unauthorized distribution.</p>
          
          <h4>What we collect:</h4>
          <ul>
            <li>Hardware fingerprint (non-personal)</li>
            <li>System information</li>
            <li>Usage patterns</li>
            <li>IP address and location</li>
          </ul>
          
          <h4>Why we collect it:</h4>
          <ul>
            <li>Verify legitimate software usage</li>
            <li>Detect and prevent software theft</li>
            <li>Protect our intellectual property</li>
          </ul>
          
          <p><strong>Your privacy matters:</strong> You can opt-out of tracking, but some features may be limited.</p>
          
          <div class="consent-buttons">
            <button onclick="acceptConsent()">Accept & Continue</button>
            <button onclick="declineConsent()">Decline Tracking</button>
            <a href="/privacy-policy" target="_blank">View Privacy Policy</a>
          </div>
        </div>
      `;
      
      document.body.appendChild(modal);
      
      window.acceptConsent = () => {
        document.body.removeChild(modal);
        resolve(true);
      };
      
      window.declineConsent = () => {
        document.body.removeChild(modal);
        resolve(false);
      };
    });
  }

  getLicenseKey() {
    // Get license key from secure storage or environment
    return localStorage.getItem('software_license') || 
           process.env.SOFTWARE_LICENSE ||
           prompt('Please enter your license key:');
  }

  async initializeApp() {
    // Your actual application initialization code
    console.log('Initializing main application...');
    
    // Example: Load user data, connect to services, etc.
    await this.loadUserData();
    await this.connectToServices();
    this.setupUI();
  }

  showProtectionError() {
    const errorDiv = document.createElement('div');
    errorDiv.innerHTML = `
      <div class="error-message">
        <h2>⚠️ License Verification Failed</h2>
        <p>This software requires a valid license to run.</p>
        <p>Please check your license key and internet connection.</p>
        
        <div class="error-actions">
          <button onclick="location.reload()">Retry</button>
          <button onclick="this.contactSupport()">Contact Support</button>
        </div>
      </div>
    `;
    document.body.appendChild(errorDiv);
  }

  contactSupport() {
    window.open('mailto:support@mycompany.com?subject=License Issue');
  }

  // Placeholder methods for your actual application
  async loadUserData() {
    console.log('Loading user data...');
  }

  async connectToServices() {
    console.log('Connecting to services...');
  }

  setupUI() {
    console.log('Setting up user interface...');
  }

  handleInitializationError(error) {
    console.error('Application initialization failed:', error);
    // Show user-friendly error message
    // Log error for debugging
    // Potentially fall back to limited functionality
  }
}

// Example 4: Server-Side License Generation
async function generateLicenseExample() {
  // This would typically be done through an admin interface
  const licenseData = {
    productId: 'my-software-v1',
    ownerId: 'customer@example.com',
    maxInstallations: 3,
    expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year
  };

  try {
    const response = await fetch('https://your-server.com/api/generate-license', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer your-admin-token'
      },
      body: JSON.stringify(licenseData)
    });

    const result = await response.json();
    console.log('Generated license:', result.licenseKey);
    
    // Send license to customer via email or other secure method
    
  } catch (error) {
    console.error('License generation failed:', error);
  }
}

// Example usage
document.addEventListener('DOMContentLoaded', () => {
  // Choose your integration method:
  
  // Option 1: Basic integration
  // basicIntegration();
  
  // Option 2: Advanced integration
  // advancedIntegration();
  
  // Option 3: Class-based integration (recommended)
  const app = new ProtectedApplication();
  app.initialize();
});

// Export for use in other modules
export { ProtectedApplication, basicIntegration, advancedIntegration };
