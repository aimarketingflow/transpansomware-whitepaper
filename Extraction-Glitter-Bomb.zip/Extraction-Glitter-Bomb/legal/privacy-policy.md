# Privacy Policy - Anti-Theft Protection System

**Last Updated:** [DATE]

## 1. Introduction

This Privacy Policy explains how our Anti-Theft Protection System ("the System") collects, uses, and protects information when you use our software protection services. We are committed to transparency and legal compliance with privacy regulations including GDPR, CCPA, and other applicable laws.

## 2. Information We Collect

### 2.1 License Information
- License key and product identification
- License holder information
- Installation and activation data
- License expiration and status

### 2.2 System Information (With Your Consent)
- Hardware fingerprint (non-personally identifiable)
- Operating system and browser information
- Screen resolution and system specifications
- IP address and approximate geographic location
- Usage timestamps and patterns

### 2.3 Security Information
- Failed verification attempts
- Suspicious activity patterns
- System access logs

## 3. How We Use Your Information

### 3.1 Primary Purposes
- **License Verification:** Validate legitimate software usage
- **Anti-Piracy Protection:** Detect and prevent unauthorized distribution
- **Security Monitoring:** Identify suspicious activities and potential theft
- **Legal Compliance:** Maintain records for potential legal proceedings

### 3.2 Data Processing Legal Basis
- **Legitimate Interest:** Protecting intellectual property and preventing theft
- **Contract Performance:** Enforcing license agreements
- **Consent:** For optional tracking features (you can opt-out)

## 4. Data Sharing and Disclosure

### 4.1 We Do NOT Share Your Data With:
- Third-party advertisers
- Data brokers
- Marketing companies
- Social media platforms

### 4.2 We MAY Share Data With:
- **Law Enforcement:** When required by law or to investigate theft
- **Legal Counsel:** For advice on intellectual property protection
- **Service Providers:** Secure hosting and database services (under strict contracts)

## 5. Your Rights and Choices

### 5.1 Opt-Out Rights
- **Tracking Opt-Out:** Disable system information collection
- **Data Deletion:** Request removal of your data
- **Data Portability:** Receive a copy of your data
- **Correction:** Update inaccurate information

### 5.2 How to Exercise Your Rights
- Email: privacy@[yourcompany].com
- Include your license key and specific request
- We will respond within 30 days

## 6. Data Security

### 6.1 Security Measures
- Encryption in transit and at rest
- Access controls and authentication
- Regular security audits
- Secure data centers

### 6.2 Data Retention
- License data: Retained for license lifetime + 2 years
- Usage logs: Retained for 2 years maximum
- Security logs: Retained for 3 years for legal purposes
- You can request earlier deletion

## 7. International Data Transfers

If you are located outside our primary jurisdiction, your data may be transferred to and processed in countries with different privacy laws. We ensure adequate protection through:
- Standard Contractual Clauses
- Adequacy decisions
- Other approved transfer mechanisms

## 8. Children's Privacy

Our services are not intended for children under 16. We do not knowingly collect information from children. If you believe we have collected information from a child, please contact us immediately.

## 9. Changes to This Policy

We may update this policy to reflect:
- Changes in our practices
- Legal requirements
- Service improvements

We will notify you of material changes via:
- Email to license holders
- Prominent notice in our software
- Updated version date

## 10. Contact Information

**Privacy Officer:** [Name]
**Email:** privacy@[yourcompany].com
**Address:** [Your Company Address]
**Phone:** [Phone Number]

**Data Protection Officer (EU):** [If applicable]
**Email:** dpo@[yourcompany].com

## 11. Legal Compliance

### 11.1 GDPR Compliance (EU Users)
- Lawful basis for processing
- Data subject rights
- Data Protection Officer contact
- Right to lodge complaints with supervisory authorities

### 11.2 CCPA Compliance (California Users)
- Right to know what information is collected
- Right to delete personal information
- Right to opt-out of sale (we don't sell data)
- Non-discrimination for exercising rights

### 11.3 Other Jurisdictions
We comply with applicable privacy laws in all jurisdictions where we operate.

## 12. Dispute Resolution

For privacy-related disputes:
1. Contact our Privacy Officer first
2. Use alternative dispute resolution if available
3. Contact relevant supervisory authorities
4. Legal remedies as applicable

---

**Acknowledgment:** By using our software with tracking enabled, you acknowledge that you have read and understood this Privacy Policy and consent to the collection and use of information as described herein.
