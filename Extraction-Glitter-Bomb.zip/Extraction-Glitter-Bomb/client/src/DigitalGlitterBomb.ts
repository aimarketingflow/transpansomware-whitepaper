/**
 * 🎆 DIGITAL GLITTER BOMB 💣
 * 
 * The ultimate legal honeypot for software thieves!
 * 
 * How it works:
 * 1. Thief steals your software
 * 2. Software is encrypted/locked until they consent
 * 3. To unlock it, they MUST click "I Accept" to tracking
 * 4. Once they accept, the glitter bomb explodes! ✨
 * 5. Every action is tracked and reported back to you
 * 6. You have legal consent + evidence of theft
 * 
 * They literally consent to their own capture! 🕵️‍♂️
 */

import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';

export interface GlitterBombConfig {
  serverUrl: string;
  productId: string;
  encryptionKey?: string;
  honeypotMode: boolean;
  collectEverything: boolean; // When true, collect maximum legal data
}

export interface ThiefProfile {
  sessionId: string;
  hardwareFingerprint: string;
  ipAddress: string;
  location: any;
  systemInfo: any;
  behaviorPattern: any;
  consentTimestamp: Date;
  evidenceCollected: string[];
}

export class DigitalGlitterBomb {
  private config: GlitterBombConfig;
  private sessionId: string;
  private isExploded: boolean = false;
  private thiefProfile: Partial<ThiefProfile> = {};
  private evidenceCollected: string[] = [];

  constructor(config: GlitterBombConfig) {
    this.config = config;
    this.sessionId = uuidv4();
    
    console.log('🎆 Digital Glitter Bomb Armed and Ready! 💣');
  }

  /**
   * 💥 THE MAIN TRAP 💥
   * This is called when someone tries to use your software
   * They CANNOT proceed without explicit consent!
   */
  async armTrap(): Promise<boolean> {
    try {
      // Check if software is already unlocked for legitimate user
      if (this.isLegitimateUser()) {
        return true;
      }

      // 🚨 POTENTIAL THIEF DETECTED! 🚨
      console.log('🚨 Unauthorized access detected - Arming glitter bomb...');
      
      // Show the unavoidable consent trap
      const consentGiven = await this.showGlitterBombConsent();
      
      if (consentGiven) {
        // 💥 BOOM! Glitter bomb exploded! 💥
        await this.explodeGlitterBomb();
        return true; // Let them use the software (while we track everything)
      } else {
        // No consent = no access (software stays locked)
        this.showAccessDenied();
        return false;
      }
      
    } catch (error) {
      console.error('Glitter bomb malfunction:', error);
      return false;
    }
  }

  /**
   * 🍯 THE HONEYPOT CONSENT DIALOG 🍯
   * This is the trap - they MUST accept to proceed!
   */
  private async showGlitterBombConsent(): Promise<boolean> {
    return new Promise((resolve) => {
      // Create an unavoidable, full-screen consent dialog
      const trapDialog = document.createElement('div');
      trapDialog.id = 'glitter-bomb-trap';
      trapDialog.style.cssText = `
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: linear-gradient(45deg, #ff6b6b, #4ecdc4, #45b7d1, #f9ca24);
        background-size: 400% 400%;
        animation: glitterShimmer 3s ease infinite;
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: Arial, sans-serif;
      `;

      trapDialog.innerHTML = `
        <style>
          @keyframes glitterShimmer {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
          }
          .glitter-bomb-modal {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            max-width: 600px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            border: 3px solid #ffd700;
          }
          .glitter-title {
            font-size: 2.5em;
            margin-bottom: 20px;
            background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
          }
          .consent-text {
            font-size: 1.1em;
            line-height: 1.6;
            margin-bottom: 30px;
            color: #333;
          }
          .warning-box {
            background: #fff3cd;
            border: 2px solid #ffc107;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
          }
          .accept-btn {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
            border: none;
            padding: 15px 40px;
            font-size: 1.2em;
            border-radius: 50px;
            cursor: pointer;
            margin: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: transform 0.2s;
          }
          .accept-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 7px 20px rgba(0,0,0,0.3);
          }
          .decline-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 30px;
            font-size: 1em;
            border-radius: 25px;
            cursor: pointer;
            margin: 10px;
          }
        </style>
        
        <div class="glitter-bomb-modal">
          <div class="glitter-title">🎆 Welcome! 🎆</div>
          
          <div class="consent-text">
            <p><strong>This software includes advanced security monitoring.</strong></p>
            <p>To proceed, you must agree to our data collection practices:</p>
          </div>
          
          <div class="warning-box">
            <h4>⚠️ IMPORTANT NOTICE ⚠️</h4>
            <p><strong>By clicking "I ACCEPT", you explicitly consent to:</strong></p>
            <ul style="text-align: left; margin: 15px 0;">
              <li>🔍 Complete system monitoring and data collection</li>
              <li>📍 IP address and geographic location tracking</li>
              <li>🖥️ Hardware fingerprinting and system identification</li>
              <li>📊 Usage pattern analysis and behavioral tracking</li>
              <li>🚨 Automatic reporting of suspicious activities</li>
              <li>📧 Notifications sent to software owner</li>
              <li>⚖️ Data retention for legal proceedings if needed</li>
            </ul>
            <p><strong>This consent is legally binding and cannot be revoked while using this software.</strong></p>
          </div>
          
          <div class="consent-text">
            <p>🔒 <strong>No consent = No access</strong></p>
            <p>The software will remain locked until you accept these terms.</p>
          </div>
          
          <div>
            <button class="accept-btn" onclick="acceptGlitterBomb()">
              ✨ I ACCEPT - UNLOCK SOFTWARE ✨
            </button>
            <br>
            <button class="decline-btn" onclick="declineGlitterBomb()">
              ❌ Decline (Software Remains Locked)
            </button>
          </div>
          
          <div style="margin-top: 20px; font-size: 0.9em; color: #666;">
            <p>By using this software, you acknowledge that unauthorized use may constitute theft.</p>
            <p>All activities are logged and may be used as evidence in legal proceedings.</p>
          </div>
        </div>
      `;

      document.body.appendChild(trapDialog);

      // Disable escape routes
      this.disableEscapeRoutes();

      // Set up the trap buttons
      (window as any).acceptGlitterBomb = () => {
        console.log('💥 GLITTER BOMB TRIGGERED! Thief accepted consent! 💥');
        this.recordConsentEvidence();
        document.body.removeChild(trapDialog);
        resolve(true);
      };

      (window as any).declineGlitterBomb = () => {
        console.log('🔒 Access denied - No consent given');
        document.body.removeChild(trapDialog);
        resolve(false);
      };
    });
  }

  /**
   * 💥 EXPLODE THE GLITTER BOMB! 💥
   * Start collecting EVERYTHING (with their consent!)
   */
  private async explodeGlitterBomb(): Promise<void> {
    this.isExploded = true;
    
    console.log('🎆💥 GLITTER BOMB EXPLODED! 💥🎆');
    console.log('🕵️‍♂️ Now collecting evidence with full legal consent...');

    // Start the evidence collection party! 🎉
    await this.collectMaximumEvidence();
    await this.startContinuousTracking();
    await this.reportToHomeBase();
    
    // Show a "thank you" message (with a hint of what's happening)
    this.showGlitterBombActivated();
  }

  /**
   * 🔍 COLLECT MAXIMUM EVIDENCE 🔍
   * They consented, so collect EVERYTHING legally possible!
   */
  private async collectMaximumEvidence(): Promise<void> {
    const evidence = {
      // Basic system info
      timestamp: new Date().toISOString(),
      sessionId: this.sessionId,
      userAgent: navigator.userAgent,
      language: navigator.language,
      languages: navigator.languages,
      platform: navigator.platform,
      
      // Screen and display info
      screenResolution: `${screen.width}x${screen.height}`,
      screenColorDepth: screen.colorDepth,
      screenPixelDepth: screen.pixelDepth,
      windowSize: `${window.innerWidth}x${window.innerHeight}`,
      
      // Timezone and location clues
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      timezoneOffset: new Date().getTimezoneOffset(),
      
      // Hardware fingerprinting
      hardwareFingerprint: await this.generateHardwareFingerprint(),
      
      // Browser capabilities
      cookieEnabled: navigator.cookieEnabled,
      onlineStatus: navigator.onLine,
      
      // Performance info
      memoryInfo: (performance as any).memory ? {
        usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
        totalJSHeapSize: (performance as any).memory.totalJSHeapSize
      } : null,
      
      // Connection info
      connectionType: (navigator as any).connection ? (navigator as any).connection.effectiveType : null,
      
      // Consent evidence
      consentGiven: true,
      consentTimestamp: new Date(),
      consentMethod: 'explicit_click_acceptance'
    };

    this.thiefProfile = { 
      ...this.thiefProfile, 
      ...evidence,
      consentTimestamp: new Date(),
      evidenceCollected: this.evidenceCollected
    };
    this.evidenceCollected.push('system_fingerprint', 'consent_record', 'hardware_profile');
    
    console.log('📋 Evidence collected:', Object.keys(evidence).length, 'data points');
  }

  /**
   * 🔄 CONTINUOUS TRACKING 🔄
   * Keep collecting data while they use the software
   */
  private async startContinuousTracking(): Promise<void> {
    // Track mouse movements (behavioral analysis)
    document.addEventListener('mousemove', (e) => {
      if (this.isExploded) {
        this.recordBehavior('mouse_movement', { x: e.clientX, y: e.clientY, timestamp: Date.now() });
      }
    });

    // Track keyboard patterns
    document.addEventListener('keydown', (e) => {
      if (this.isExploded) {
        this.recordBehavior('key_press', { key: e.key, timestamp: Date.now() });
      }
    });

    // Track window focus/blur (are they switching apps?)
    window.addEventListener('blur', () => {
      if (this.isExploded) {
        this.recordBehavior('window_blur', { timestamp: Date.now() });
      }
    });

    // Periodic check-ins
    setInterval(() => {
      if (this.isExploded) {
        this.sendPeriodicUpdate();
      }
    }, 30000); // Every 30 seconds

    console.log('🔄 Continuous tracking activated - Every move is being monitored!');
  }

  /**
   * 📡 REPORT TO HOME BASE 📡
   * Send all evidence back to you
   */
  private async reportToHomeBase(): Promise<void> {
    try {
      const payload = {
        alert_type: 'GLITTER_BOMB_EXPLODED',
        session_id: this.sessionId,
        product_id: this.config.productId,
        thief_profile: this.thiefProfile,
        evidence_collected: this.evidenceCollected,
        explosion_time: new Date().toISOString(),
        message: '🎆💥 GLITTER BOMB EXPLODED! Thief caught with full consent! 💥🎆'
      };

      await fetch(`${this.config.serverUrl}/api/glitter-bomb-explosion`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      console.log('📡 Evidence successfully transmitted to home base!');
      
    } catch (error) {
      console.error('📡 Failed to report to home base:', error);
      // Store locally and retry later
      localStorage.setItem('glitter_bomb_evidence', JSON.stringify(this.thiefProfile));
    }
  }

  /**
   * 🎨 GENERATE HARDWARE FINGERPRINT 🎨
   * Create a unique identifier for this thief's machine
   */
  private async generateHardwareFingerprint(): Promise<string> {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    
    // Create a unique canvas fingerprint
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillStyle = '#f60';
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = '#069';
    ctx.fillText('🎆 Glitter Bomb Fingerprint 💣', 2, 15);
    ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
    ctx.fillText('Digital Evidence Collection', 4, 45);

    const canvasData = canvas.toDataURL();
    
    // Combine with other hardware indicators
    const fingerprint = [
      canvasData,
      navigator.userAgent,
      navigator.language,
      screen.width + 'x' + screen.height,
      new Date().getTimezoneOffset(),
      navigator.platform,
      navigator.cookieEnabled
    ].join('|');

    return CryptoJS.SHA256(fingerprint).toString();
  }

  /**
   * 📝 RECORD BEHAVIOR 📝
   * Track what the thief is doing
   */
  private recordBehavior(action: string, data: any): void {
    const behaviorRecord = {
      action,
      data,
      timestamp: Date.now(),
      session_id: this.sessionId
    };

    // Store behavior pattern
    if (!this.thiefProfile.behaviorPattern) {
      this.thiefProfile.behaviorPattern = [];
    }
    this.thiefProfile.behaviorPattern.push(behaviorRecord);

    // Send critical behaviors immediately
    if (['window_blur', 'suspicious_key_combination'].includes(action)) {
      this.sendImmediateAlert(behaviorRecord);
    }
  }

  /**
   * 🚨 SEND IMMEDIATE ALERT 🚨
   */
  private async sendImmediateAlert(behavior: any): Promise<void> {
    try {
      await fetch(`${this.config.serverUrl}/api/immediate-alert`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'suspicious_behavior',
          session_id: this.sessionId,
          behavior: behavior,
          timestamp: new Date().toISOString()
        })
      });
    } catch (error) {
      console.error('Failed to send immediate alert:', error);
    }
  }

  /**
   * ✨ SHOW GLITTER BOMB ACTIVATED MESSAGE ✨
   */
  private showGlitterBombActivated(): void {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: linear-gradient(45deg, #ffd700, #ffed4e);
      color: #333;
      padding: 15px 25px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
      z-index: 10000;
      font-weight: bold;
      animation: glitterPulse 2s ease-in-out infinite;
    `;
    
    notification.innerHTML = '✨ Security Monitoring Active ✨';
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        document.body.removeChild(notification);
      }
    }, 5000);
  }

  /**
   * 🔒 DISABLE ESCAPE ROUTES 🔒
   */
  private disableEscapeRoutes(): void {
    // Disable common escape key combinations
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' || 
          (e.ctrlKey && (e.key === 'w' || e.key === 'q')) ||
          e.key === 'F4' && e.altKey) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
    });

    // Disable right-click context menu
    document.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      return false;
    });
  }

  /**
   * 📋 RECORD CONSENT EVIDENCE 📋
   */
  private recordConsentEvidence(): void {
    const consentEvidence = {
      timestamp: new Date().toISOString(),
      method: 'explicit_button_click',
      ip_address: 'will_be_logged_server_side',
      user_agent: navigator.userAgent,
      session_id: this.sessionId,
      consent_text_shown: true,
      legal_warnings_displayed: true,
      user_had_choice: true,
      consent_freely_given: true
    };

    this.evidenceCollected.push('explicit_consent_record');
    console.log('📋 Legal consent evidence recorded:', consentEvidence);
  }

  /**
   * 🔍 CHECK IF LEGITIMATE USER 🔍
   */
  private isLegitimateUser(): boolean {
    // Check for legitimate user indicators (USB key, license file, etc.)
    const hasValidUSB = localStorage.getItem('legitimate_usb_key');
    const hasValidLicense = localStorage.getItem('valid_license_verified');
    
    return !!(hasValidUSB || hasValidLicense);
  }

  /**
   * ❌ SHOW ACCESS DENIED ❌
   */
  private showAccessDenied(): void {
    document.body.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: center; height: 100vh; 
                  background: #f8f9fa; font-family: Arial, sans-serif;">
        <div style="text-align: center; padding: 40px; background: white; border-radius: 10px; 
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
          <h1 style="color: #dc3545;">🔒 Access Denied</h1>
          <p>This software requires explicit consent to data collection.</p>
          <p>Without consent, the software cannot be unlocked.</p>
          <button onclick="location.reload()" style="padding: 10px 20px; margin-top: 20px; 
                  background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            Try Again
          </button>
        </div>
      </div>
    `;
  }

  /**
   * 📊 SEND PERIODIC UPDATE 📊
   */
  private async sendPeriodicUpdate(): Promise<void> {
    try {
      await fetch(`${this.config.serverUrl}/api/periodic-update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: this.sessionId,
          timestamp: new Date().toISOString(),
          still_active: true,
          behavior_count: this.thiefProfile.behaviorPattern?.length || 0
        })
      });
    } catch (error) {
      console.error('Failed to send periodic update:', error);
    }
  }

  /**
   * 🎯 GET THIEF PROFILE 🎯
   */
  getThiefProfile(): ThiefProfile | null {
    return this.isExploded ? this.thiefProfile as ThiefProfile : null;
  }

  /**
   * 💣 IS BOMB EXPLODED? 💣
   */
  isBombExploded(): boolean {
    return this.isExploded;
  }
}
