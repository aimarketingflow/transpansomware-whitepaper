/**
 * Legal Anti-Theft Protection System
 * Transparent, user-consented software protection
 */

import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';

export interface ProtectionConfig {
  serverUrl: string;
  licenseKey: string;
  productId: string;
  enableTracking: boolean;
  userConsent: boolean;
}

export interface SystemInfo {
  timestamp: number;
  userAgent: string;
  language: string;
  timezone: string;
  screenResolution: string;
  hardwareFingerprint: string;
}

export class AntiTheftProtection {
  private config: ProtectionConfig;
  private sessionId: string;
  private isInitialized: boolean = false;

  constructor(config: ProtectionConfig) {
    this.config = config;
    this.sessionId = uuidv4();
    
    // Show consent dialog if tracking enabled
    if (config.enableTracking && !config.userConsent) {
      this.showConsentDialog();
    }
  }

  /**
   * Initialize protection system with user consent
   */
  async initialize(): Promise<boolean> {
    try {
      // Verify license first
      const licenseValid = await this.verifyLicense();
      if (!licenseValid) {
        throw new Error('Invalid license detected');
      }

      // If user consented to tracking, collect system info
      if (this.config.userConsent && this.config.enableTracking) {
        await this.reportUsage();
      }

      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error('Protection initialization failed:', error);
      return false;
    }
  }

  /**
   * Verify software license with server
   */
  private async verifyLicense(): Promise<boolean> {
    try {
      const response = await fetch(`${this.config.serverUrl}/api/verify-license`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          licenseKey: this.config.licenseKey,
          productId: this.config.productId,
          sessionId: this.sessionId
        })
      });

      const result = await response.json();
      return result.valid === true;
    } catch (error) {
      console.error('License verification failed:', error);
      return false;
    }
  }

  /**
   * Collect system information (with user consent)
   */
  private collectSystemInfo(): SystemInfo {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx!.textBaseline = 'top';
    ctx!.font = '14px Arial';
    ctx!.fillText('Hardware fingerprint', 2, 2);
    
    return {
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      screenResolution: `${screen.width}x${screen.height}`,
      hardwareFingerprint: CryptoJS.SHA256(canvas.toDataURL()).toString()
    };
  }

  /**
   * Report usage to tracking server (only with consent)
   */
  private async reportUsage(): Promise<void> {
    if (!this.config.userConsent) return;

    try {
      const systemInfo = this.collectSystemInfo();
      
      await fetch(`${this.config.serverUrl}/api/report-usage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          licenseKey: this.config.licenseKey,
          productId: this.config.productId,
          sessionId: this.sessionId,
          systemInfo: systemInfo,
          consentGiven: true
        })
      });
    } catch (error) {
      console.error('Usage reporting failed:', error);
    }
  }

  /**
   * Show consent dialog for data collection
   */
  private showConsentDialog(): void {
    const dialog = document.createElement('div');
    dialog.innerHTML = `
      <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
                  background: rgba(0,0,0,0.8); z-index: 10000; display: flex; 
                  align-items: center; justify-content: center;">
        <div style="background: white; padding: 30px; border-radius: 10px; 
                    max-width: 500px; text-align: center;">
          <h3>Software Protection Notice</h3>
          <p>This software includes anti-theft protection. We collect minimal 
             system information to verify legitimate usage and protect against piracy.</p>
          <p><strong>Data collected:</strong> Hardware fingerprint, system info, usage patterns</p>
          <p><strong>Purpose:</strong> License verification and anti-piracy protection</p>
          <p>You can opt-out, but some features may be limited.</p>
          <button id="consent-accept" style="margin: 10px; padding: 10px 20px; 
                  background: #007cba; color: white; border: none; border-radius: 5px;">
            Accept & Continue
          </button>
          <button id="consent-decline" style="margin: 10px; padding: 10px 20px; 
                  background: #ccc; color: black; border: none; border-radius: 5px;">
            Decline Tracking
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(dialog);

    document.getElementById('consent-accept')!.onclick = () => {
      this.config.userConsent = true;
      document.body.removeChild(dialog);
      this.initialize();
    };

    document.getElementById('consent-decline')!.onclick = () => {
      this.config.userConsent = false;
      this.config.enableTracking = false;
      document.body.removeChild(dialog);
      this.initialize();
    };
  }

  /**
   * Check if protection is active
   */
  isProtectionActive(): boolean {
    return this.isInitialized;
  }

  /**
   * Get session information
   */
  getSessionInfo() {
    return {
      sessionId: this.sessionId,
      trackingEnabled: this.config.enableTracking,
      consentGiven: this.config.userConsent
    };
  }
}
