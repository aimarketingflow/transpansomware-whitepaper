/**
 * 🎆💣 GLITTER BOMB SERVER ROUTES 💣🎆
 * 
 * Handles the server-side processing when a glitter bomb explodes!
 * This is where all the juicy thief data gets processed and stored.
 */

import express from 'express';
import { body, validationResult } from 'express-validator';
import { DatabaseManager } from './database';
import { AlertSystem } from './alert-system';
import geoip from 'geoip-lite';

const router = express.Router();

/**
 * 💥 GLITTER BOMB EXPLOSION ENDPOINT 💥
 * Called when a thief accepts consent and the bomb explodes
 */
router.post('/glitter-bomb-explosion', [
  body('alert_type').equals('GLITTER_BOMB_EXPLODED'),
  body('session_id').isUUID(),
  body('product_id').isAlphanumeric(),
  body('thief_profile').isObject(),
  body('explosion_time').isISO8601()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const {
      session_id,
      product_id,
      thief_profile,
      evidence_collected,
      explosion_time,
      message
    } = req.body;

    const clientIP = req.ip || req.connection.remoteAddress;
    const userAgent = req.get('User-Agent') || '';
    const geoInfo = geoip.lookup(clientIP);

    console.log('🎆💥 GLITTER BOMB EXPLODED! 💥🎆');
    console.log('🕵️‍♂️ Thief Profile:', {
      session_id,
      ip: clientIP,
      location: geoInfo ? `${geoInfo.city}, ${geoInfo.country}` : 'Unknown',
      evidence_count: evidence_collected?.length || 0
    });

    // Store the explosion data
    const db = new DatabaseManager();
    await db.initialize();

    // Create a special "glitter bomb" alert
    await db.createAlert({
      type: 'GLITTER_BOMB_EXPLODED',
      licenseKey: 'HONEYPOT_TRAP',
      productId: product_id,
      clientIP: clientIP,
      details: {
        session_id,
        thief_profile,
        evidence_collected,
        explosion_time,
        geo_location: geoInfo,
        user_agent: userAgent,
        consent_given: true,
        legal_status: 'EXPLICIT_CONSENT_OBTAINED',
        threat_level: 'CONFIRMED_THEFT_WITH_CONSENT'
      },
      timestamp: new Date()
    });

    // Log detailed thief information
    await db.logUsage({
      licenseKey: 'GLITTER_BOMB_TRAP',
      productId: product_id,
      sessionId: session_id,
      clientIP: clientIP,
      systemInfo: thief_profile,
      location: geoInfo ? {
        country: geoInfo.country,
        region: geoInfo.region,
        city: geoInfo.city
      } : undefined,
      consentGiven: true, // They explicitly consented!
      timestamp: new Date()
    });

    // Send high-priority alert
    const alertSystem = new AlertSystem({
      emailNotifications: true,
      webhookUrl: process.env.WEBHOOK_URL,
      slackWebhook: process.env.SLACK_WEBHOOK_URL,
      emailRecipients: ['security@yourcompany.com']
    });

    await alertSystem.triggerAlert({
      type: 'GLITTER_BOMB_EXPLODED',
      licenseKey: 'HONEYPOT_TRAP',
      productId: product_id,
      clientIP: clientIP,
      details: {
        message: '🎆💥 DIGITAL GLITTER BOMB EXPLODED! THIEF CAUGHT WITH CONSENT! 💥🎆',
        session_id,
        evidence_summary: {
          hardware_fingerprint: thief_profile.hardwareFingerprint ? 'Collected' : 'Missing',
          system_info: 'Complete',
          behavioral_data: 'Active Collection',
          consent_status: 'EXPLICIT_CONSENT_GIVEN',
          legal_admissibility: 'HIGH - Voluntary Consent'
        },
        recommended_actions: [
          '🔍 Monitor continued activity in real-time',
          '📊 Analyze behavioral patterns for additional evidence',
          '📧 Document all evidence for potential legal action',
          '🚨 Consider escalating to law enforcement if theft confirmed',
          '💼 Prepare intellectual property protection case'
        ],
        thief_location: geoInfo ? `${geoInfo.city}, ${geoInfo.region}, ${geoInfo.country}` : 'Unknown',
        evidence_strength: 'MAXIMUM - Consent + Usage + System Data'
      },
      timestamp: new Date()
    });

    console.log('🎯 Thief successfully trapped and evidence secured!');

    res.json({
      success: true,
      message: '💥 Glitter bomb explosion recorded successfully',
      session_id: session_id,
      evidence_logged: true,
      alerts_sent: true,
      legal_status: 'CONSENT_OBTAINED_EVIDENCE_ADMISSIBLE'
    });

  } catch (error) {
    console.error('💥 Glitter bomb processing error:', error);
    res.status(500).json({ 
      error: 'Failed to process glitter bomb explosion',
      session_id: req.body.session_id 
    });
  }
});

/**
 * 🚨 IMMEDIATE ALERT ENDPOINT 🚨
 * For real-time suspicious behavior alerts
 */
router.post('/immediate-alert', [
  body('type').isString(),
  body('session_id').isUUID(),
  body('behavior').isObject()
], async (req, res) => {
  try {
    const { type, session_id, behavior } = req.body;
    const clientIP = req.ip || req.connection.remoteAddress;

    console.log('🚨 IMMEDIATE ALERT:', type, 'from session:', session_id);

    // Log the suspicious behavior
    const db = new DatabaseManager();
    await db.initialize();

    await db.createAlert({
      type: 'SUSPICIOUS_BEHAVIOR_REALTIME',
      clientIP: clientIP,
      details: {
        behavior_type: type,
        session_id,
        behavior_data: behavior,
        alert_level: 'IMMEDIATE',
        timestamp: new Date().toISOString()
      },
      timestamp: new Date()
    });

    // Send immediate notification for critical behaviors
    if (['devtools_opened', 'storage_clear_attempt', 'network_tampering'].includes(type)) {
      const alertSystem = new AlertSystem();
      await alertSystem.triggerAlert({
        type: 'CRITICAL_BEHAVIOR_DETECTED',
        clientIP: clientIP,
        details: {
          message: `🚨 CRITICAL: Thief attempting ${type.replace('_', ' ')}`,
          session_id,
          behavior,
          urgency: 'HIGH'
        },
        timestamp: new Date()
      });
    }

    res.json({ success: true, alert_logged: true });

  } catch (error) {
    console.error('🚨 Immediate alert error:', error);
    res.status(500).json({ error: 'Failed to process immediate alert' });
  }
});

/**
 * 📊 PERIODIC UPDATE ENDPOINT 📊
 * Regular check-ins from active glitter bombs
 */
router.post('/periodic-update', [
  body('session_id').isUUID(),
  body('still_active').isBoolean()
], async (req, res) => {
  try {
    const { session_id, still_active, behavior_count } = req.body;
    const clientIP = req.ip || req.connection.remoteAddress;

    // Update the session activity
    console.log(`📊 Periodic update from ${session_id}: Active=${still_active}, Behaviors=${behavior_count}`);

    // Store activity update
    const db = new DatabaseManager();
    await db.initialize();

    await db.logUsage({
      licenseKey: 'GLITTER_BOMB_ACTIVE',
      productId: 'periodic_update',
      sessionId: session_id,
      clientIP: clientIP,
      systemInfo: {
        update_type: 'periodic_checkin',
        still_active,
        behavior_count,
        timestamp: new Date().toISOString()
      },
      consentGiven: true,
      timestamp: new Date()
    });

    res.json({ 
      success: true, 
      continue_tracking: true,
      next_checkin_seconds: 30 
    });

  } catch (error) {
    console.error('📊 Periodic update error:', error);
    res.status(500).json({ error: 'Failed to process periodic update' });
  }
});

/**
 * 📈 GLITTER BOMB ANALYTICS ENDPOINT 📈
 * Get statistics about glitter bomb explosions
 */
router.get('/analytics', async (req, res) => {
  try {
    const db = new DatabaseManager();
    await db.initialize();

    // Get glitter bomb statistics
    const stats = {
      total_explosions: 0,
      active_sessions: 0,
      evidence_collected: 0,
      geographic_distribution: {},
      recent_explosions: []
    };

    // In a real implementation, you'd query the database for these stats
    // This is a placeholder structure

    res.json({
      success: true,
      analytics: stats,
      message: '🎆 Glitter bomb analytics retrieved successfully'
    });

  } catch (error) {
    console.error('📈 Analytics error:', error);
    res.status(500).json({ error: 'Failed to retrieve analytics' });
  }
});

/**
 * 🎯 THIEF PROFILE ENDPOINT 🎯
 * Get detailed information about a specific thief session
 */
router.get('/thief-profile/:session_id', async (req, res) => {
  try {
    const { session_id } = req.params;
    
    const db = new DatabaseManager();
    await db.initialize();

    // Get all data for this session
    // In a real implementation, you'd query for usage logs, alerts, etc.
    
    res.json({
      success: true,
      session_id: session_id,
      profile: {
        // Thief profile data would be here
        message: '🕵️‍♂️ Thief profile data would be retrieved from database'
      }
    });

  } catch (error) {
    console.error('🎯 Thief profile error:', error);
    res.status(500).json({ error: 'Failed to retrieve thief profile' });
  }
});

export default router;
