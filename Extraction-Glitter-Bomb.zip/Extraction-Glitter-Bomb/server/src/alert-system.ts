/**
 * Alert System - Handles suspicious activity notifications and alerts
 */

import { DatabaseManager } from './database';

export interface Alert {
  type: string;
  licenseKey?: string;
  productId?: string;
  clientIP?: string;
  details: any;
  timestamp: Date;
}

export interface AlertConfig {
  emailNotifications: boolean;
  webhookUrl?: string;
  slackWebhook?: string;
  emailRecipients: string[];
}

export class AlertSystem {
  private config: AlertConfig;
  private db?: DatabaseManager;

  constructor(config?: Partial<AlertConfig>) {
    this.config = {
      emailNotifications: false,
      emailRecipients: [],
      ...config
    };
  }

  setDatabase(db: DatabaseManager) {
    this.db = db;
  }

  async triggerAlert(alert: Alert): Promise<void> {
    try {
      // Store alert in database
      if (this.db) {
        await this.db.createAlert(alert);
      }

      // Log to console (always)
      console.log('🚨 SECURITY ALERT:', {
        type: alert.type,
        licenseKey: alert.licenseKey ? `${alert.licenseKey.substring(0, 8)}...` : 'N/A',
        productId: alert.productId,
        clientIP: alert.clientIP,
        details: alert.details,
        timestamp: alert.timestamp.toISOString()
      });

      // Send notifications based on alert type and severity
      await this.sendNotifications(alert);

    } catch (error) {
      console.error('Failed to process alert:', error);
    }
  }

  private async sendNotifications(alert: Alert): Promise<void> {
    const severity = this.calculateSeverity(alert);
    
    // Only send notifications for medium and high severity alerts
    if (severity === 'low') return;

    const message = this.formatAlertMessage(alert, severity);

    // Send webhook notification
    if (this.config.webhookUrl) {
      await this.sendWebhook(message, alert);
    }

    // Send Slack notification
    if (this.config.slackWebhook) {
      await this.sendSlackNotification(message, alert, severity);
    }

    // Send email notification (if configured)
    if (this.config.emailNotifications && this.config.emailRecipients.length > 0) {
      await this.sendEmailNotification(message, alert, severity);
    }
  }

  private calculateSeverity(alert: Alert): 'low' | 'medium' | 'high' {
    switch (alert.type) {
      case 'suspicious_license_usage':
        if (alert.details.includes('multiple countries') || 
            alert.details.includes('different IPs in the last hour')) {
          return 'high';
        }
        return 'medium';
      
      case 'suspicious_usage_pattern':
        if (alert.details.includes('bot') || alert.details.includes('Virtual machine')) {
          return 'medium';
        }
        return 'low';
      
      case 'license_brute_force':
        return 'high';
      
      default:
        return 'medium';
    }
  }

  private formatAlertMessage(alert: Alert, severity: 'low' | 'medium' | 'high'): string {
    const severityEmoji = {
      low: '⚠️',
      medium: '🚨',
      high: '🔥'
    };

    const maskedLicense = alert.licenseKey ? 
      `${alert.licenseKey.substring(0, 8)}...` : 'Unknown';

    return `${severityEmoji[severity]} **${severity.toUpperCase()} SECURITY ALERT**

**Type:** ${alert.type.replace(/_/g, ' ').toUpperCase()}
**License:** ${maskedLicense}
**Product:** ${alert.productId || 'Unknown'}
**IP Address:** ${alert.clientIP || 'Unknown'}
**Time:** ${alert.timestamp.toISOString()}

**Details:**
${Array.isArray(alert.details) ? alert.details.join('\n') : JSON.stringify(alert.details, null, 2)}

**Recommended Actions:**
${this.getRecommendedActions(alert.type)}`;
  }

  private getRecommendedActions(alertType: string): string {
    switch (alertType) {
      case 'suspicious_license_usage':
        return `• Review license usage patterns
• Contact license holder to verify legitimate use
• Consider temporarily suspending license if confirmed theft
• Document evidence for potential legal action`;

      case 'suspicious_usage_pattern':
        return `• Investigate system fingerprint anomalies
• Check for automated/bot usage
• Verify user consent for data collection
• Monitor for continued suspicious behavior`;

      case 'license_brute_force':
        return `• Immediately block suspicious IP addresses
• Increase rate limiting
• Alert license holders of potential breach
• Consider implementing additional security measures`;

      default:
        return `• Investigate the alert details
• Document findings
• Take appropriate security measures
• Monitor for escalation`;
    }
  }

  private async sendWebhook(message: string, alert: Alert): Promise<void> {
    if (!this.config.webhookUrl) return;

    try {
      const response = await fetch(this.config.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          alert_type: alert.type,
          message: message,
          license_key: alert.licenseKey,
          product_id: alert.productId,
          client_ip: alert.clientIP,
          timestamp: alert.timestamp.toISOString(),
          details: alert.details
        })
      });

      if (!response.ok) {
        console.error('Webhook notification failed:', response.statusText);
      }
    } catch (error) {
      console.error('Failed to send webhook notification:', error);
    }
  }

  private async sendSlackNotification(message: string, alert: Alert, severity: string): Promise<void> {
    if (!this.config.slackWebhook) return;

    const color = {
      low: '#ffeb3b',
      medium: '#ff9800',
      high: '#f44336'
    }[severity];

    try {
      const response = await fetch(this.config.slackWebhook, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          attachments: [{
            color: color,
            title: `Security Alert: ${alert.type.replace(/_/g, ' ')}`,
            text: message,
            footer: 'Anti-Theft Protection System',
            ts: Math.floor(alert.timestamp.getTime() / 1000)
          }]
        })
      });

      if (!response.ok) {
        console.error('Slack notification failed:', response.statusText);
      }
    } catch (error) {
      console.error('Failed to send Slack notification:', error);
    }
  }

  private async sendEmailNotification(message: string, alert: Alert, severity: string): Promise<void> {
    // Email implementation would depend on your email service
    // This is a placeholder for the email notification logic
    console.log('Email notification would be sent to:', this.config.emailRecipients);
    console.log('Subject: Security Alert -', alert.type);
    console.log('Message:', message);
    
    // In a real implementation, you would integrate with services like:
    // - SendGrid
    // - AWS SES
    // - Nodemailer with SMTP
    // - etc.
  }

  async getRecentAlerts(hours: number = 24): Promise<Alert[]> {
    // This would query the database for recent alerts
    // Implementation depends on your database structure
    return [];
  }

  async resolveAlert(alertId: number): Promise<void> {
    // Mark an alert as resolved in the database
    if (this.db) {
      // Implementation would update the alert status
      console.log(`Alert ${alertId} marked as resolved`);
    }
  }
}
