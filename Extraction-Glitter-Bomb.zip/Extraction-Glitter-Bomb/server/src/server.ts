/**
 * Legal Anti-Theft Protection Server
 * Handles license verification and usage tracking with full transparency
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { RateLimiterMemory } from 'rate-limiter-flexible';
import { body, validationResult } from 'express-validator';
import geoip from 'geoip-lite';
import { DatabaseManager } from './database';
import { LicenseManager } from './license-manager';
import { AlertSystem } from './alert-system';
import glitterBombRoutes from './glitter-bomb-routes';

const app = express();
const PORT = process.env.PORT || 3001;

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));

// Rate limiting
const rateLimiter = new RateLimiterMemory({
  keyGenerator: (req) => req.ip,
  points: 100, // Number of requests
  duration: 60, // Per 60 seconds
});

// Initialize systems
const db = new DatabaseManager();
const licenseManager = new LicenseManager(db);
const alertSystem = new AlertSystem();

// 🎆 Mount Glitter Bomb routes 🎆
app.use('/api', glitterBombRoutes);

// Rate limiting middleware
app.use(async (req, res, next) => {
  try {
    await rateLimiter.consume(req.ip);
    next();
  } catch (rejRes) {
    res.status(429).json({ error: 'Too many requests' });
  }
});

/**
 * License verification endpoint
 */
app.post('/api/verify-license', [
  body('licenseKey').isLength({ min: 10 }).withMessage('Invalid license key'),
  body('productId').isAlphanumeric().withMessage('Invalid product ID'),
  body('sessionId').isUUID().withMessage('Invalid session ID')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { licenseKey, productId, sessionId } = req.body;
    const clientIP = req.ip || req.connection.remoteAddress;
    const userAgent = req.get('User-Agent') || '';
    
    // Get geographic info (for legitimate tracking)
    const geoInfo = geoip.lookup(clientIP);
    
    const verification = await licenseManager.verifyLicense({
      licenseKey,
      productId,
      sessionId,
      clientIP,
      userAgent,
      location: geoInfo ? {
        country: geoInfo.country,
        region: geoInfo.region,
        city: geoInfo.city
      } : null,
      timestamp: new Date()
    });

    // Log verification attempt
    await db.logVerification({
      licenseKey,
      productId,
      sessionId,
      clientIP,
      userAgent,
      success: verification.valid,
      reason: verification.reason,
      timestamp: new Date()
    });

    // Check for suspicious activity
    if (verification.suspicious) {
      await alertSystem.triggerAlert({
        type: 'suspicious_license_usage',
        licenseKey,
        productId,
        clientIP,
        details: verification.suspiciousReasons,
        timestamp: new Date()
      });
    }

    res.json({
      valid: verification.valid,
      message: verification.message,
      sessionId: sessionId
    });

  } catch (error) {
    console.error('License verification error:', error);
    res.status(500).json({ error: 'Verification failed' });
  }
});

/**
 * Usage reporting endpoint (only with user consent)
 */
app.post('/api/report-usage', [
  body('licenseKey').isLength({ min: 10 }),
  body('productId').isAlphanumeric(),
  body('sessionId').isUUID(),
  body('consentGiven').isBoolean(),
  body('systemInfo').isObject()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { licenseKey, productId, sessionId, systemInfo, consentGiven } = req.body;
    
    // Only process if user gave explicit consent
    if (!consentGiven) {
      return res.status(400).json({ error: 'User consent required for tracking' });
    }

    const clientIP = req.ip || req.connection.remoteAddress;
    const geoInfo = geoip.lookup(clientIP);

    // Store usage data
    await db.logUsage({
      licenseKey,
      productId,
      sessionId,
      clientIP,
      systemInfo,
      location: geoInfo ? {
        country: geoInfo.country,
        region: geoInfo.region,
        city: geoInfo.city
      } : null,
      consentGiven: true,
      timestamp: new Date()
    });

    // Analyze for suspicious patterns
    const analysis = await licenseManager.analyzeUsagePattern({
      licenseKey,
      productId,
      clientIP,
      systemInfo
    });

    if (analysis.suspicious) {
      await alertSystem.triggerAlert({
        type: 'suspicious_usage_pattern',
        licenseKey,
        productId,
        clientIP,
        details: analysis.reasons,
        timestamp: new Date()
      });
    }

    res.json({ 
      success: true, 
      message: 'Usage reported successfully',
      sessionId: sessionId
    });

  } catch (error) {
    console.error('Usage reporting error:', error);
    res.status(500).json({ error: 'Reporting failed' });
  }
});

/**
 * Privacy policy endpoint
 */
app.get('/api/privacy-policy', (req, res) => {
  res.json({
    policy: {
      dataCollected: [
        'License key and product information',
        'IP address and geographic location',
        'System fingerprint (hardware-based)',
        'Browser and system information',
        'Usage timestamps and patterns'
      ],
      purpose: [
        'License verification and validation',
        'Anti-piracy and theft protection',
        'Suspicious activity detection',
        'Legal compliance and evidence collection'
      ],
      retention: '2 years or until license expires',
      userRights: [
        'Right to opt-out of tracking',
        'Right to data deletion',
        'Right to data portability',
        'Right to be informed of data breaches'
      ],
      contact: 'privacy@yourcompany.com'
    }
  });
});

/**
 * Health check endpoint
 */
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// Error handling middleware
app.use((error: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Server error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// Initialize database and start server
async function startServer() {
  try {
    await db.initialize();
    console.log('Database initialized');
    
    app.listen(PORT, () => {
      console.log(`🛡️  Anti-theft protection server running on port ${PORT}`);
      console.log(`📋 Privacy policy available at: http://localhost:${PORT}/api/privacy-policy`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
