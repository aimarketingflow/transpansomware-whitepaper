/**
 * Database Manager for Anti-Theft Protection System
 * Handles all data storage with privacy compliance
 */

import sqlite3 from 'sqlite3';
import { promisify } from 'util';

export interface LicenseRecord {
  id?: number;
  licenseKey: string;
  productId: string;
  isActive: boolean;
  maxInstallations: number;
  currentInstallations: number;
  createdAt: Date;
  expiresAt?: Date;
  ownerId: string;
}

export interface VerificationLog {
  id?: number;
  licenseKey: string;
  productId: string;
  sessionId: string;
  clientIP: string;
  userAgent: string;
  success: boolean;
  reason?: string;
  timestamp: Date;
}

export interface UsageLog {
  id?: number;
  licenseKey: string;
  productId: string;
  sessionId: string;
  clientIP: string;
  systemInfo: any;
  location?: {
    country: string;
    region: string;
    city: string;
  };
  consentGiven: boolean;
  timestamp: Date;
}

export class DatabaseManager {
  private db: sqlite3.Database;
  private dbPath: string;

  constructor(dbPath: string = './protection.db') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.db = new sqlite3.Database(this.dbPath, (err) => {
        if (err) {
          reject(err);
          return;
        }
        
        this.createTables()
          .then(() => resolve())
          .catch(reject);
      });
    });
  }

  private async createTables(): Promise<void> {
    const run = promisify(this.db.run.bind(this.db));

    // Licenses table
    await run(`
      CREATE TABLE IF NOT EXISTS licenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        license_key TEXT UNIQUE NOT NULL,
        product_id TEXT NOT NULL,
        is_active BOOLEAN DEFAULT 1,
        max_installations INTEGER DEFAULT 1,
        current_installations INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME,
        owner_id TEXT NOT NULL
      )
    `);

    // Verification logs table
    await run(`
      CREATE TABLE IF NOT EXISTS verification_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        license_key TEXT NOT NULL,
        product_id TEXT NOT NULL,
        session_id TEXT NOT NULL,
        client_ip TEXT NOT NULL,
        user_agent TEXT,
        success BOOLEAN NOT NULL,
        reason TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (license_key) REFERENCES licenses(license_key)
      )
    `);

    // Usage logs table (only with consent)
    await run(`
      CREATE TABLE IF NOT EXISTS usage_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        license_key TEXT NOT NULL,
        product_id TEXT NOT NULL,
        session_id TEXT NOT NULL,
        client_ip TEXT NOT NULL,
        system_info TEXT, -- JSON string
        location_country TEXT,
        location_region TEXT,
        location_city TEXT,
        consent_given BOOLEAN NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (license_key) REFERENCES licenses(license_key)
      )
    `);

    // Alerts table
    await run(`
      CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        alert_type TEXT NOT NULL,
        license_key TEXT,
        product_id TEXT,
        client_ip TEXT,
        details TEXT, -- JSON string
        resolved BOOLEAN DEFAULT 0,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create indexes for performance
    await run('CREATE INDEX IF NOT EXISTS idx_license_key ON verification_logs(license_key)');
    await run('CREATE INDEX IF NOT EXISTS idx_client_ip ON verification_logs(client_ip)');
    await run('CREATE INDEX IF NOT EXISTS idx_timestamp ON verification_logs(timestamp)');
    await run('CREATE INDEX IF NOT EXISTS idx_usage_license ON usage_logs(license_key)');
    await run('CREATE INDEX IF NOT EXISTS idx_alerts_type ON alerts(alert_type)');
  }

  async createLicense(license: Omit<LicenseRecord, 'id'>): Promise<number> {
    const run = promisify(this.db.run.bind(this.db));
    
    const result = await run(`
      INSERT INTO licenses (
        license_key, product_id, is_active, max_installations, 
        current_installations, expires_at, owner_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [
      license.licenseKey,
      license.productId,
      license.isActive ? 1 : 0,
      license.maxInstallations,
      license.currentInstallations,
      license.expiresAt?.toISOString(),
      license.ownerId
    ]);

    return (result as any).lastID;
  }

  async getLicense(licenseKey: string): Promise<LicenseRecord | null> {
    const get = promisify(this.db.get.bind(this.db));
    
    const row = await get(`
      SELECT * FROM licenses WHERE license_key = ?
    `, [licenseKey]);

    if (!row) return null;

    return {
      id: row.id,
      licenseKey: row.license_key,
      productId: row.product_id,
      isActive: Boolean(row.is_active),
      maxInstallations: row.max_installations,
      currentInstallations: row.current_installations,
      createdAt: new Date(row.created_at),
      expiresAt: row.expires_at ? new Date(row.expires_at) : undefined,
      ownerId: row.owner_id
    };
  }

  async logVerification(log: Omit<VerificationLog, 'id'>): Promise<void> {
    const run = promisify(this.db.run.bind(this.db));
    
    await run(`
      INSERT INTO verification_logs (
        license_key, product_id, session_id, client_ip, 
        user_agent, success, reason
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [
      log.licenseKey,
      log.productId,
      log.sessionId,
      log.clientIP,
      log.userAgent,
      log.success ? 1 : 0,
      log.reason
    ]);
  }

  async logUsage(log: Omit<UsageLog, 'id'>): Promise<void> {
    const run = promisify(this.db.run.bind(this.db));
    
    await run(`
      INSERT INTO usage_logs (
        license_key, product_id, session_id, client_ip, 
        system_info, location_country, location_region, 
        location_city, consent_given
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      log.licenseKey,
      log.productId,
      log.sessionId,
      log.clientIP,
      JSON.stringify(log.systemInfo),
      log.location?.country,
      log.location?.region,
      log.location?.city,
      log.consentGiven ? 1 : 0
    ]);
  }

  async getRecentVerifications(licenseKey: string, hours: number = 24): Promise<VerificationLog[]> {
    const all = promisify(this.db.all.bind(this.db));
    
    const rows = await all(`
      SELECT * FROM verification_logs 
      WHERE license_key = ? 
      AND timestamp > datetime('now', '-${hours} hours')
      ORDER BY timestamp DESC
    `, [licenseKey]);

    return rows.map(row => ({
      id: row.id,
      licenseKey: row.license_key,
      productId: row.product_id,
      sessionId: row.session_id,
      clientIP: row.client_ip,
      userAgent: row.user_agent,
      success: Boolean(row.success),
      reason: row.reason,
      timestamp: new Date(row.timestamp)
    }));
  }

  async getSuspiciousActivity(): Promise<any[]> {
    const all = promisify(this.db.all.bind(this.db));
    
    // Find licenses with multiple IPs in short time
    const suspiciousIPs = await all(`
      SELECT license_key, COUNT(DISTINCT client_ip) as ip_count,
             GROUP_CONCAT(DISTINCT client_ip) as ips
      FROM verification_logs 
      WHERE timestamp > datetime('now', '-24 hours')
      GROUP BY license_key
      HAVING ip_count > 3
    `);

    return suspiciousIPs;
  }

  async createAlert(alert: {
    type: string;
    licenseKey?: string;
    productId?: string;
    clientIP?: string;
    details: any;
    timestamp: Date;
  }): Promise<void> {
    const run = promisify(this.db.run.bind(this.db));
    
    await run(`
      INSERT INTO alerts (alert_type, license_key, product_id, client_ip, details)
      VALUES (?, ?, ?, ?, ?)
    `, [
      alert.type,
      alert.licenseKey,
      alert.productId,
      alert.clientIP,
      JSON.stringify(alert.details)
    ]);
  }

  async close(): Promise<void> {
    return new Promise((resolve) => {
      this.db.close(() => {
        resolve();
      });
    });
  }
}
