/**
 * License Manager - Handles license verification and suspicious activity detection
 */

import { DatabaseManager, LicenseRecord } from './database';
import crypto from 'crypto';

export interface VerificationRequest {
  licenseKey: string;
  productId: string;
  sessionId: string;
  clientIP: string;
  userAgent: string;
  location?: {
    country: string;
    region: string;
    city: string;
  };
  timestamp: Date;
}

export interface VerificationResult {
  valid: boolean;
  message: string;
  reason?: string;
  suspicious: boolean;
  suspiciousReasons?: string[];
}

export interface UsageAnalysis {
  suspicious: boolean;
  reasons: string[];
  riskLevel: 'low' | 'medium' | 'high';
}

export class LicenseManager {
  constructor(private db: DatabaseManager) {}

  async verifyLicense(request: VerificationRequest): Promise<VerificationResult> {
    try {
      // Get license from database
      const license = await this.db.getLicense(request.licenseKey);
      
      if (!license) {
        return {
          valid: false,
          message: 'Invalid license key',
          reason: 'license_not_found',
          suspicious: true,
          suspiciousReasons: ['Unknown license key attempted']
        };
      }

      // Check if license is active
      if (!license.isActive) {
        return {
          valid: false,
          message: 'License is deactivated',
          reason: 'license_inactive',
          suspicious: false
        };
      }

      // Check if license has expired
      if (license.expiresAt && license.expiresAt < new Date()) {
        return {
          valid: false,
          message: 'License has expired',
          reason: 'license_expired',
          suspicious: false
        };
      }

      // Check product ID match
      if (license.productId !== request.productId) {
        return {
          valid: false,
          message: 'Invalid product ID for this license',
          reason: 'product_mismatch',
          suspicious: true,
          suspiciousReasons: ['License used with wrong product']
        };
      }

      // Analyze for suspicious activity
      const suspiciousActivity = await this.detectSuspiciousActivity(request, license);

      return {
        valid: true,
        message: 'License verified successfully',
        suspicious: suspiciousActivity.suspicious,
        suspiciousReasons: suspiciousActivity.reasons
      };

    } catch (error) {
      console.error('License verification error:', error);
      return {
        valid: false,
        message: 'Verification failed',
        reason: 'system_error',
        suspicious: false
      };
    }
  }

  private async detectSuspiciousActivity(
    request: VerificationRequest, 
    license: LicenseRecord
  ): Promise<{ suspicious: boolean; reasons: string[] }> {
    const reasons: string[] = [];
    
    // Get recent verifications for this license
    const recentVerifications = await this.db.getRecentVerifications(request.licenseKey, 24);
    
    // Check for multiple IP addresses
    const uniqueIPs = new Set(recentVerifications.map(v => v.clientIP));
    if (uniqueIPs.size > license.maxInstallations * 2) {
      reasons.push(`License used from ${uniqueIPs.size} different IP addresses in 24 hours`);
    }

    // Check for rapid successive attempts from different IPs
    const recentIPs = recentVerifications
      .filter(v => v.timestamp > new Date(Date.now() - 60 * 60 * 1000)) // Last hour
      .map(v => v.clientIP);
    
    const uniqueRecentIPs = new Set(recentIPs);
    if (uniqueRecentIPs.size > 3) {
      reasons.push(`License accessed from ${uniqueRecentIPs.size} different IPs in the last hour`);
    }

    // Check for excessive verification attempts
    const failedAttempts = recentVerifications.filter(v => !v.success).length;
    if (failedAttempts > 10) {
      reasons.push(`${failedAttempts} failed verification attempts in 24 hours`);
    }

    return {
      suspicious: reasons.length > 0,
      reasons
    };
  }

  async analyzeUsagePattern(data: {
    licenseKey: string;
    productId: string;
    clientIP: string;
    systemInfo: any;
  }): Promise<UsageAnalysis> {
    const reasons: string[] = [];
    let riskLevel: 'low' | 'medium' | 'high' = 'low';

    try {
      // Check for suspicious system characteristics
      if (data.systemInfo.userAgent && data.systemInfo.userAgent.includes('bot')) {
        reasons.push('Automated/bot user agent detected');
        riskLevel = 'medium';
      }

      // Check for virtual machine indicators
      if (data.systemInfo.hardwareFingerprint && 
          (data.systemInfo.hardwareFingerprint.includes('VMware') || 
           data.systemInfo.hardwareFingerprint.includes('VirtualBox'))) {
        reasons.push('Virtual machine environment detected');
        riskLevel = 'medium';
      }

      // Check screen resolution anomalies
      if (data.systemInfo.screenResolution) {
        const [width, height] = data.systemInfo.screenResolution.split('x').map(Number);
        if (width < 800 || height < 600) {
          reasons.push('Unusually small screen resolution');
        }
      }

    } catch (error) {
      console.error('Usage pattern analysis error:', error);
    }

    return {
      suspicious: reasons.length > 0,
      reasons,
      riskLevel
    };
  }

  async generateLicense(productId: string, ownerId: string, maxInstallations: number = 1): Promise<string> {
    // Generate a secure license key
    const licenseKey = this.generateSecureLicenseKey();
    
    await this.db.createLicense({
      licenseKey,
      productId,
      isActive: true,
      maxInstallations,
      currentInstallations: 0,
      createdAt: new Date(),
      ownerId
    });

    return licenseKey;
  }

  private generateSecureLicenseKey(): string {
    // Generate a cryptographically secure license key
    const randomBytes = crypto.randomBytes(16);
    const timestamp = Date.now().toString(36);
    const hash = crypto.createHash('sha256')
      .update(randomBytes)
      .update(timestamp)
      .digest('hex');
    
    // Format as XXXX-XXXX-XXXX-XXXX
    const key = hash.substring(0, 16).toUpperCase();
    return `${key.substring(0, 4)}-${key.substring(4, 8)}-${key.substring(8, 12)}-${key.substring(12, 16)}`;
  }
}
